"use client";
import React from "react";

function MainComponent() {
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [playerPosition, setPlayerPosition] = useState(50);
  const [obstacles, setObstacles] = useState([]);
  const [speed, setSpeed] = useState(1.5);
  const [isCrashing, setIsCrashing] = useState(false);
  const gameAreaRef = useRef(null);
  const animationFrameRef = useRef(null);
  const lastTimestampRef = useRef(0);
  const crashAudioRef = useRef(null);

  const resetGame = () => {
    setGameStarted(false);
    setGameOver(false);
    setScore(0);
    setPlayerPosition(50);
    setObstacles([]);
    setSpeed(1.5);
    setIsCrashing(false);
  };
  const handleKeyDown = useCallback(
    (e) => {
      if (!gameStarted || gameOver) return;

      if (e.key === "ArrowLeft") {
        setPlayerPosition((prev) => Math.max(10, prev - 10));
      } else if (e.key === "ArrowRight") {
        setPlayerPosition((prev) => Math.min(90, prev + 10));
      } else if (e.key === "ArrowUp") {
        setSpeed((prev) => Math.min(6, prev + 0.2));
      } else if (e.key === "ArrowDown") {
        setSpeed((prev) => Math.max(1, prev - 0.2));
      }
    },
    [gameStarted, gameOver]
  );
  const handleTouch = useCallback(
    (e) => {
      if (!gameStarted || gameOver) return;

      const touch = e.touches[0];
      const gameArea = gameAreaRef.current;
      if (!gameArea) return;

      const rect = gameArea.getBoundingClientRect();
      const relativeX = ((touch.clientX - rect.left) / rect.width) * 100;

      setPlayerPosition((prev) => {
        const target = Math.min(90, Math.max(10, relativeX));
        const diff = target - prev;
        return prev + diff * 0.2;
      });
    },
    [gameStarted, gameOver]
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown]);

  const gameLoop = useCallback(
    (timestamp) => {
      if (!lastTimestampRef.current) lastTimestampRef.current = timestamp;
      const deltaTime = timestamp - lastTimestampRef.current;

      if (deltaTime > 16) {
        setScore((prev) => prev + 1);

        if (Math.random() < 0.02 * (speed / 3)) {
          const newObstacle = {
            x: Math.random() * 80 + 10,
            y: -10,
            id: Date.now(),
          };
          setObstacles((prev) => [...prev, newObstacle]);
        }

        setObstacles((prev) => {
          const updated = prev
            .map((obs) => ({
              ...obs,
              y: obs.y + speed,
            }))
            .filter((obs) => obs.y < 110);

          const collision = updated.some(
            (obs) =>
              Math.abs(obs.x - playerPosition) < 7 && Math.abs(obs.y - 80) < 7
          );

          if (collision && !isCrashing) {
            setIsCrashing(true);
            if (crashAudioRef.current) {
              crashAudioRef.current.play().catch(() => {});
            }
            setTimeout(() => {
              setGameOver(true);
              setHighScore((prev) => Math.max(prev, score));
            }, 1500);
            return updated;
          }

          return updated;
        });

        lastTimestampRef.current = timestamp;
      }

      if (!gameOver) {
        animationFrameRef.current = requestAnimationFrame(gameLoop);
      }
    },
    [score, playerPosition, speed, gameOver, isCrashing]
  );

  useEffect(() => {
    if (gameStarted && !gameOver) {
      animationFrameRef.current = requestAnimationFrame(gameLoop);
    }
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [gameStarted, gameOver, gameLoop]);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex flex-col items-center justify-center p-4">
      <div className="text-gray-900 dark:text-white font-inter mb-4 text-center">
        <h1 className="text-2xl font-bold mb-2">Car Racing Game</h1>
        <p className="text-sm">
          Use LEFT/RIGHT arrows to move your car
          <br />
          Use UP/DOWN arrows to control traffic speed
        </p>
      </div>

      <div
        ref={gameAreaRef}
        className="relative w-full max-w-[400px] h-[600px] bg-gray-800 dark:bg-gray-700 overflow-hidden rounded-lg"
        onTouchMove={handleTouch}
      >
        <div className="absolute top-4 left-4 flex gap-2 z-10">
          <button
            onClick={() => setSpeed((prev) => Math.min(6, prev + 0.2))}
            className="bg-gray-900 text-white px-3 py-1 rounded hover:bg-gray-800 transition-colors font-inter text-sm"
          >
            Faster
          </button>
          <button
            onClick={() => setSpeed((prev) => Math.max(1, prev - 0.2))}
            className="bg-gray-900 text-white px-3 py-1 rounded hover:bg-gray-800 transition-colors font-inter text-sm"
          >
            Slower
          </button>
        </div>
        <div className="absolute top-4 right-4 text-white font-inter">
          <div>Score: {score}</div>
          <div>High Score: {highScore}</div>
          <div>Traffic Speed: {speed.toFixed(1)}x</div>
        </div>
        <div className="animate-roadMove absolute w-full h-full">
          <div className="absolute left-1/3 h-full w-[4px] bg-white"></div>
          <div className="absolute right-1/3 h-full w-[4px] bg-white"></div>
        </div>

        {obstacles.map((obstacle) => (
          <div
            key={obstacle.id}
            className="obstacle-car"
            style={{
              left: `${obstacle.x}%`,
              top: `${obstacle.y}%`,
            }}
          >
            <div className="obstacle-body"></div>
            <div className="obstacle-hood"></div>
            <div className="obstacle-windows"></div>
            <div className="obstacle-wheel-left"></div>
            <div className="obstacle-wheel-right"></div>
            <div className="obstacle-spoiler"></div>
            <div className="headlight-left"></div>
            <div className="headlight-right"></div>
          </div>
        ))}

        <div
          className={`player-car ${isCrashing ? "crash" : ""}`}
          style={{
            left: `${playerPosition}%`,
            bottom: "10%",
          }}
        >
          <div className="car-body"></div>
          <div className="car-hood"></div>
          <div className="car-windows"></div>
          <div className="car-spoiler"></div>
          <div className="wheel-left"></div>
          <div className="wheel-right"></div>
          <div className="headlight-left"></div>
          <div className="headlight-right"></div>
          <div className="car-boost boost-left"></div>
          <div className="car-boost boost-right"></div>
          {isCrashing && (
            <>
              <div className="spark spark-1"></div>
              <div className="spark spark-2"></div>
              <div className="spark spark-3"></div>
              <div className="smoke"></div>
              <div className="damage-decal"></div>
            </>
          )}
          <audio ref={crashAudioRef} src="/crash.mp3" preload="auto" />
        </div>

        {!gameStarted && !gameOver && (
          <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <button
              onClick={() => setGameStarted(true)}
              className="bg-gray-900 text-white px-6 py-2 rounded hover:bg-gray-800 transition-colors font-inter"
            >
              Start Game
            </button>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-50">
            <div className="text-white font-inter text-xl mb-4">Game Over!</div>
            <button
              onClick={resetGame}
              className="bg-gray-900 text-white px-6 py-2 rounded hover:bg-gray-800 transition-colors font-inter"
            >
              Play Again
            </button>
          </div>
        )}
      </div>

      <style jsx global>{`
        .player-car {
          width: 50px;
          height: 70px;
          position: absolute;
          transform-style: preserve-3d;
          transform: translate(-50%, 0);
          animation: carBob 0.6s infinite;
          transition: left 0.1s linear, transform 0.1s ease;
        }
        .player-car.crash {
          animation: crashEffect 1.5s forwards;
        }
        .car-body {
          position: absolute;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, #2bdb2b, #33ff33);
          border-radius: 12px 12px 8px 8px;
          clip-path: polygon(15% 0, 85% 0, 100% 40%, 100% 100%, 0 100%, 0 40%);
          box-shadow: 0 4px 8px rgba(0,0,0,0.3);
          transition: filter 0.2s;
        }
        .crash .car-body {
          animation: damageFlash 0.2s infinite;
          filter: brightness(1.5) saturate(1.5);
        }
        .spark {
          position: absolute;
          width: 4px;
          height: 4px;
          background: #fff;
          border-radius: 50%;
          opacity: 0;
        }
        .crash .spark {
          animation: sparkFly 0.5s ease-out forwards;
        }
        .crash .spark-1 { animation-delay: 0s; }
        .crash .spark-2 { animation-delay: 0.1s; }
        .crash .spark-3 { animation-delay: 0.2s; }
        .smoke {
          position: absolute;
          width: 30px;
          height: 30px;
          background: rgba(100, 100, 100, 0.8);
          border-radius: 50%;
          opacity: 0;
          filter: blur(4px);
        }
        .crash .smoke {
          animation: smokeRise 1.5s ease-out forwards;
        }
        .damage-decal {
          position: absolute;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, transparent 45%, rgba(0,0,0,0.3) 55%);
          opacity: 0;
        }
        .crash .damage-decal {
          animation: showDamage 0.2s forwards;
        }
        @keyframes crashEffect {
          0% { transform: translate(-50%, 0) rotate(0deg); }
          20% { transform: translate(-55%, -5%) rotate(-15deg); }
          40% { transform: translate(-45%, 0%) rotate(10deg); }
          60% { transform: translate(-50%, -2%) rotate(-5deg); }
          100% { transform: translate(-50%, 0) rotate(0deg) scale(0.9); opacity: 0.7; }
        }
        @keyframes damageFlash {
          0%, 100% { filter: brightness(1.5) saturate(1.5); }
          50% { filter: brightness(2) saturate(2) hue-rotate(45deg); }
        }
        @keyframes sparkFly {
          0% { 
            opacity: 1;
            transform: translate(0, 0); 
          }
          100% { 
            opacity: 0;
            transform: translate(
              calc(${Math.random() * 100 - 50}px),
              calc(${Math.random() * -100}px)
            );
          }
        }
        @keyframes smokeRise {
          0% { 
            opacity: 0;
            transform: translate(0, 0) scale(0.5);
          }
          20% { opacity: 0.8; }
          100% { 
            opacity: 0;
            transform: translate(0, -100px) scale(2);
          }
        }
        @keyframes showDamage {
          0% { opacity: 0; }
          100% { opacity: 1; }
        }
        .car-windows {
          position: absolute;
          width: 60%;
          height: 40%;
          top: 15%;
          left: 20%;
          background: #1e293b;
          clip-path: polygon(20% 0, 80% 0, 100% 100%, 0 100%);
          border-radius: 4px;
        }
        .car-hood {
          position: absolute;
          width: 90%;
          height: 30%;
          top: 5%;
          left: 5%;
          background: linear-gradient(45deg, #29c229, #2bdb2b);
          clip-path: polygon(20% 0, 80% 0, 100% 100%, 0 100%);
        }
        .car-spoiler {
          position: absolute;
          width: 80%;
          height: 10px;
          bottom: 15%;
          left: 10%;
          background: #1e293b;
          border-radius: 2px;
        }
        .car-boost {
          position: absolute;
          width: 8px;
          height: 15px;
          bottom: -15px;
          background: linear-gradient(to top, transparent, #007fff);
          border-radius: 4px;
          opacity: 0.7;
          animation: boostFlicker 0.2s infinite;
        }
        .boost-left { left: 25%; }
        .boost-right { right: 25%; }
        .wheel-left, .wheel-right {
          position: absolute;
          width: 12px;
          height: 20px;
          background: #1e293b;
          border-radius: 6px;
          bottom: 5px;
          box-shadow: inset 0 0 4px rgba(255,255,255,0.3);
        }
        .wheel-left { left: 2px; }
        .wheel-right { right: 2px; }
        .headlight-left, .headlight-right {
          position: absolute;
          width: 8px;
          height: 8px;
          background: #ff3333;
          border-radius: 50%;
          bottom: 15px;
        }
        .headlight-left { left: 5px; }
        .headlight-right { right: 5px; }
        .obstacle-car {
          width: 50px;
          height: 70px;
          position: absolute;
          transform-style: preserve-3d;
          transform: translate(-50%, -50%);
          animation: carBob 0.6s infinite;
        }
        .obstacle-body {
          position: absolute;
          width: 100%;
          height: 100%;
          background: linear-gradient(45deg, #cc2b2b, #ff3333);
          border-radius: 12px 12px 8px 8px;
          clip-path: polygon(15% 0, 85% 0, 100% 40%, 100% 100%, 0 100%, 0 40%);
          box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
        .obstacle-hood {
          position: absolute;
          width: 90%;
          height: 30%;
          top: 5%;
          left: 5%;
          background: linear-gradient(45deg, #b91c1c, #cc2b2b);
          clip-path: polygon(20% 0, 80% 0, 100% 100%, 0 100%);
        }
        .obstacle-windows {
          position: absolute;
          width: 60%;
          height: 40%;
          top: 15%;
          left: 20%;
          background: #1e293b;
          clip-path: polygon(20% 0, 80% 0, 100% 100%, 0 100%);
          border-radius: 4px;
        }
        .obstacle-spoiler {
          position: absolute;
          width: 80%;
          height: 10px;
          bottom: 15%;
          left: 10%;
          background: #1e293b;
          border-radius: 2px;
        }
        .obstacle-wheel-left, .obstacle-wheel-right {
          position: absolute;
          width: 12px;
          height: 20px;
          background: #1e293b;
          border-radius: 6px;
          bottom: 5px;
          box-shadow: inset 0 0 4px rgba(255,255,255,0.3);
        }
        .obstacle-wheel-left { left: 2px; }
        .obstacle-wheel-right { right: 2px; }
        @keyframes carBob {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-2px); }
        }
        @keyframes boostFlicker {
          0%, 100% { opacity: 0.7; }
          50% { opacity: 0.9; }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;